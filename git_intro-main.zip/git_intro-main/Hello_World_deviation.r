print("Please enter a number of times you would like to repeat Hello World")
#read in an integer
var = readline();
# convert the inputted value to integer
var = as.integer(var);
#while loop
i=1
while(i < (var+1)){
  print("Hello World")
  i=i+1
}
  
