%hello world matlab
%git can host a repo with multiple different languages simultaneously
%however unless explicitly coerced, do not expect the files from different
%languages to interact effectively

x = "hello world";

for i = 1:5
    x
end

   