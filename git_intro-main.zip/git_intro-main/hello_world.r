#Sample R File.  
#Pound creates a comment

print("Hello World")

#declaration
x <- "Hello World"
x

#loop to reiterate statement
for (i in 1:5){
  print(x)
}
